#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <assert.h>
#include <stdint.h>
#include <sys/select.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>




#include "memory_pool.h"
#include "queue_sendAddr_dataLenth.h"
#include "sock_pack.h"
#include "escape_char.h"
#include "socklog.h"
#include "server_simple.h"
#include "func_compont.h"
#include "template_scan_element_type.h"

#if 0
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#endif

#define 	ERRORINPUT


#define 	SCAN_SOURCE_DIR  "sourcefile"
#define 	CERT_FILE 	"/home/yyx/nanhao/server/server-cert.pem" 
#define 	KEY_FILE  	"/home/yyx/nanhao/server/server-key.pem" 
#define 	CA_FILE 	"/home/yyx/nanhao/ca/ca-cert.pem" 			/*Trusted CAs location*/
#define 	CIPHER_LIST "AES128-SHA"								/*Cipher list to be used*/
#define 	NUMBER		15
#define		MY_MIN(x, y)	((x) < (y) ? (x) : (y))	
#define     SCAN_TIME 	15
char g_DirPath[512];
unsigned int g_flag = 0;							//������ ���յ� ���ݰ����к�,���л���
unsigned int g_sendFlag = 0;						//�������Լ����ݰ����к�
mem_pool_t  *g_memoryPool = NULL;					//mempool handle
queue_send_dataBLock   g_sendData_addrAndLenth_queue;
clientRequestContent  *g_requestContent = NULL;
long long int g_fileTemplateID = 562, g_fileTableID = 365;
char *g_downLoadDir = NULL;
char *g_fileNameTable = "downLoadTemplateNewestFromServer_17_05_08.pdf";
char *g_fileNameTemplate = "C_16_01_04_10_16_10_030_B_L.jpg";
int  g_listen_fd = 0;		//�����׽���


pthread_t  g_pthid_scan_dir;


pthread_mutex_t	 g_mutex_pool = PTHREAD_MUTEX_INITIALIZER; 	
pthread_mutex_t	 g_mutex_data_addrAndLenth = PTHREAD_MUTEX_INITIALIZER; 	
sem_t g_sem_send;						//send data package OK , post The sem_t

#if 0
typedef struct _RecvAndSendthid_Sockfd_{
	pthread_t		pthidWrite;
	pthread_t		pthidRead;
	int 			sockfd;
	int 			flag;					// 0: UnUse;  1: use
	SSL_CTX 		*sslCtx;				// The Once connection 
	SSL 			*sslHandle;				// The Once connection for transfer
	sem_t			sem_send;				//The send thread And recv Thread synchronization
	bool			encryptRecvFlag;		//true : encrypt, false : No encrypt
	bool			encryptSendFlag;		//ture : send data In use encyprtl, false : In use common
	bool			encryptChangeFlag;		//true : once recv cmd=14, (deal with recv And send Flag(previous)), modify to False ; false : No change		
}RecvAndSendthid_Sockfd;
#endif


typedef struct _RecvAndSendthid_Sockfd_{
	pthread_t		pthidWrite;
	pthread_t		pthidRead;
	int 			sockfd;
	int 			flag;					// 0: UnUse;  1: use	
	sem_t			sem_send;				//The send thread And recv Thread synchronization
	bool			encryptRecvFlag;		//true : encrypt, false : No encrypt
	bool			encryptSendFlag;		//ture : send data In use encyprtl, false : In use common
	bool			encryptChangeFlag;		//true : once recv cmd=14, (deal with recv And send Flag(previous)), modify to False ; false : No change		
	int 			send_flag;				//push infomation to Ui serial Number
}RecvAndSendthid_Sockfd;


RecvAndSendthid_Sockfd		g_thid_sockfd_block[NUMBER];

int removed_sockfd_buf(int sockfd);
int removefd(int sockfd);
void clear_global();			//clear global resource

//int ssl_server_init_handle(int socketfd, SSL_CTX **srcCtx, SSL **srcSsl);
int	find_whole_package(char *recvBuf, int recvLenth, int index);
void destroy_server();


void signUSR1_exit_thread(int sign)
{
	int ret = 0;
	socket_log( SocketLevel[2],ret , "\nthread:%lu, receive signal:%u---", pthread_self(), sign);
	pthread_exit(NULL);
}

void sign_usr2(int sign)
{
	int ret = 0;
	
	myprint("\n\n()()()()()()()recv signal : %d, pthread : %lu", sign, pthread_self());
	socket_log( SocketLevel[2],ret , "\nthread:%lu, receive signal:%u---", pthread_self(), sign);
}

bool if_file_exist(const char *filePath)
{
	if(filePath == NULL)
		assert(0);
	if(access(filePath, F_OK) == 0)
		return true;

	return false;
}


int init_server(char *ip, int port, char *uploadDirParh)
{
	int 			ret = 0, i = 0;
	int 			sfd, cfd;
    socklen_t 		clie_len;
	pthread_t 		pthidWrite = -1, pthidRead = -1;		//pthread ID
	struct sockaddr_in clie_addr;
	int 			conIndex = 0;
	static bool  	createFlag = false;	
	//SSL_CTX 		*ctx = NULL;	
	//SSL 			*ssl = NULL;	
	//1.���������ϴ��ļ���Ŀ¼
	if(access(uploadDirParh,  0) < 0 )
	{
		ret = mkdir(uploadDirParh, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	 	if(ret)		std_err("mkdir");	
	}
	
	memset(g_DirPath, 0, sizeof(g_DirPath));
	memcpy(g_DirPath, uploadDirParh, strlen(uploadDirParh));
	myprint("uploadPath : %s", g_DirPath);
	memset(g_thid_sockfd_block, 0, sizeof(g_thid_sockfd_block));

	//2. register signal function
	signal(SIGUSR1, signUSR1_exit_thread);
	signal(SIGPIPE, func_pipe);	//���������� �����׽���
	//signal(SIGUSR2, sign_usr2);

	//3.create The listhenSockfd And bind IP , PORT
    ret = server_bind_listen_fd(ip, port, &sfd);
    if(ret)		std_err("server_bind_listen_fd");		
    clie_len = sizeof(clie_addr); 
	g_listen_fd = sfd;

	//4.init The glabal value : : mempool And Queue
    if((g_memoryPool = mem_pool_init( 1500, 2800, &g_mutex_pool)) == NULL )
	{
		myprint("Err : func mem_pool_init() ");
		assert(0);	
	}
	if((g_sendData_addrAndLenth_queue = queue_init_send_block(1500)) == NULL)
	{
		myprint("Err : func queue_init_send_block() ");
		assert(0);	
	}

	//5.init The sem_t 	semaphore
	sem_init(&g_sem_send, 0, 0);		

	for(i = 0; i < NUMBER; i++)
		sem_init(&(g_thid_sockfd_block[i].sem_send), 0, 0);

	if((g_downLoadDir = getenv("SERverSourceDir")) == NULL)
	{
		myprint("Err : func getenv() key = SERverSourceDir");
		assert(0);
	}


	//6. accept The connect from client And create The work thread  to recv And send data
    while(1)
    {
    	 //6.1 �����ȴ��ͻ��˷�����������
    	cfd = accept(sfd, (struct sockaddr*)&clie_addr, &clie_len);
    	if(cfd == -1)
       	{
       		std_err("accept");
		}
		else
		{
		#if 0
			myprint("===========  1  ============");
			if((ret = ssl_server_init_handle(cfd , &ctx, &ssl)) < 0)
			{
				close(cfd);
				myprint("\n\nErr : func ssl_server_init_handle()... ");		
				return ret;
			}
		#endif
		}

		//6.2 training in rotation find a array element 
		do
		{
			for(conIndex = 0; conIndex < NUMBER; conIndex++)
			{
				if(g_thid_sockfd_block[conIndex].flag == 0)
					break;
			}
			if(conIndex == NUMBER)
			{
				myprint("connect MAX 100 have full, will sleep 5s, try again ");
				sleep(5);
			}
		}while(conIndex == NUMBER);
		
	
		g_thid_sockfd_block[conIndex].flag = 1;
		g_thid_sockfd_block[conIndex].sockfd= cfd;
//		g_thid_sockfd_block[conIndex].sslCtx = ctx;
//		g_thid_sockfd_block[conIndex].sslHandle = ssl;
		g_thid_sockfd_block[conIndex].encryptChangeFlag = false;
		g_thid_sockfd_block[conIndex].encryptRecvFlag = false;
		g_thid_sockfd_block[conIndex].encryptSendFlag = false;		
		g_thid_sockfd_block[conIndex].send_flag = 0;

		//�������̣߳� ȥִ�з��� ҵ��
		ret = pthread_create(&pthidWrite, NULL, child_write_func, (void *)conIndex);
		if(ret < 0)
		{
			myprint("err: func pthread_create() ");		
			return ret;
		}
		//�������̣߳� ȥִ�н��� ҵ��
		ret = pthread_create(&pthidRead, NULL, child_read_func, (void *)conIndex);
		if(ret < 0)
		{
			myprint("err: func pthread_create() ");		
			return ret;
		}
	#if 1	
		if(!createFlag)
		{
			//�������̣߳� ȥִ��ɨ��Ŀ¼ҵ��, ������Ϣ����
			ret = pthread_create(&g_pthid_scan_dir, NULL, child_scan_func, NULL);
			if(ret < 0)
			{
				myprint("err: func child_scan_func() "); 	
				return ret;
			}
			createFlag = true;
		}
	#endif	
		g_thid_sockfd_block[conIndex].pthidRead = pthidRead;
		g_thid_sockfd_block[conIndex].pthidWrite= pthidWrite;	
		
    }		

	//4.������Դ
	destroy_server();

	return ret;
}

void destroy_server()
{	
	int i = 0;
	close(g_listen_fd);
	for(i = 0; i < NUMBER; i++)
	{		
		sem_destroy(&(g_thid_sockfd_block[i].sem_send));		
	}	
	pthread_mutex_destroy(&g_mutex_pool);
	pthread_mutex_destroy(&g_mutex_data_addrAndLenth);
	mem_pool_destroy(g_memoryPool);
	destroy_queue_send_block(g_sendData_addrAndLenth_queue);
}


//select()  
void timer_select(int seconds)
{
	struct timeval temp;
 	temp.tv_sec = seconds;
    temp.tv_usec = 0;
    int err = 0;
	do{
		err = select(0, NULL, NULL, NULL, (struct timeval *)&temp);
	}while(err < 0 && errno == EINTR);

}


void *child_scan_func(void *arg)
{
	pthread_detach(pthread_self());
	
	while(1)
	{
		timer_select(SCAN_TIME);
		find_directory_file();
	}

	pthread_exit(NULL);
}


//���߳�ִ���߼�;  ����ֵ: 0:��ʶ��������, 1: ��ʶ�ͻ��˹ر�;  -1: ��ʶ����.
void *child_read_func(void *arg)
{
	int ret = 0, index = (int)arg;
	int i = 1, recvLen = 0;
	char recvBuf[10240] = { 0 };
	int clientFd = g_thid_sockfd_block[index].sockfd;
	
	pthread_detach(pthread_self());

	myprint("New Thread will recv ......");
//	printf("\n\n");
	
	signal(SIGUSR2, sign_usr2);
    //��������
    while(1)
    {  
    	memset(recvBuf, 0 ,  sizeof(recvBuf));
		if(!g_thid_sockfd_block[index].encryptRecvFlag)
	    {
	    	recvLen = read(clientFd, recvBuf, sizeof(recvBuf));
		}
		else
		{
			myprint("SSL_read function... ");
			//recvLen = SSL_read(g_thid_sockfd_block[index].sslHandle, recvBuf, sizeof(recvBuf));  
		}
		if(recvLen > 0)		//��ȷ��������, ���д���
        {    
  //      	 myprint("fucn read() recv data; recvLen : %d,  recv package index : i = %d, encryptRecvFlag : %d",
//			 	recvLen, i, g_thid_sockfd_block[index].encryptRecvFlag);          

			 if((find_whole_package(recvBuf, recvLen, index)) < 0)
			 {
			 	printf("\n\n");
				myprint("Err : func find_whole_package()");				
				printf("\n\n");
				break;	
			 }
	                 	
        	 i++;
        }
       	else if(recvLen < 0)       	//The connect sockfd Error
       	{
       		if(errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
       		{
       			myprint("************** ()()()()() server: errno == EINTR || errno == EAGAIN ");         		
    			continue;  				
       		}
       		else 
       		{
       			myprint("ERror: server recv data ");
				g_thid_sockfd_block[index].flag = 0;
				clear_global();
       			break;	
       		}       		
       	}
       	else if(recvLen == 0)		//client close
       	{
       		myprint("client closed ");
			g_thid_sockfd_block[index].flag = 0;
			clear_global();
       		break;
       	}	      	
	//	printf("\n\n");		
	} 

	
	if(g_thid_sockfd_block[index].encryptRecvFlag)
	{
		myprint("ssl_shurdown ssl sockfd");
//		SSL_shutdown(g_thid_sockfd_block[index].sslHandle);            
	}
	else
	{
		myprint("close common sockfd");
		close(clientFd);		
	}
#if 0
	SSL_free(g_thid_sockfd_block[index].sslHandle); 
	SSL_CTX_free(g_thid_sockfd_block[index].sslCtx);
#endif
	myprint("\n\n close  Thread recv .....");
	if((ret = pthread_kill(g_thid_sockfd_block[index].pthidWrite, SIGUSR1)) < 0)		assert(0);					
	pthread_exit(NULL);
	return NULL;
}


void clear_global()
{
	int elementNumber = 0, i = 0;
	char *elementStr = NULL;
	int elementLenth = 0, conIndex = 0;


	for(conIndex = 0; conIndex < NUMBER; conIndex++)
	{
		//printf("---------=========== 0 ============----------\n");
		//assert(0);
		if(g_thid_sockfd_block[conIndex].flag == 1)		return;			
	}
		
	if((elementNumber =	get_element_count_send_block(g_sendData_addrAndLenth_queue)) < 0)
	{
		myprint("Err : func get_element_count_send_block()...");
		assert(0);
		return;
	}
	//printf("---------=========== 1 ============----------\n");

	if(elementNumber > 0)
	{
		for(i = 0; i < elementNumber; i++)
		{
			if((pop_queue_send_block(g_sendData_addrAndLenth_queue, &elementStr, &elementLenth)) < 0)
			{
				myprint("Err : func get_element_count_send_block()...");
				assert(0);
			}			
			//printf("--------- %d ----------\n", i);
			if((mem_pool_free(g_memoryPool, elementStr)) < 0)
			{
				myprint("Err : func mem_pool_free()...");
				assert(0);
			}
			elementStr = NULL;
		}
	}
			//printf("---------=========== 2 ============----------\n");
	
}



//���߳�ִ���߼�;  ����ֵ: 0:��ʶ��������, 1: ��ʶ�ͻ��˹ر�;  -1: ��ʶ����.
void *child_read_func02(void *arg)
{
	int ret = 0;
	int i = 1;
	char recvBuf[10240] = { 0 };
	int recvLen = 0, clientFd = (int)arg;
	
	pthread_detach(pthread_self());

	myprint("client sockfd : %d", clientFd);
//	printf("\n\n");
	
    //��������
    while(1)
    {  

    	memset(recvBuf, 0 ,  sizeof(recvBuf));  
        recvLen = read(clientFd, recvBuf, sizeof(recvBuf));
        if(recvLen > 0)		//��ȷ��������, ���д���
        {    
        	 myprint("fucn read() recv data; recvLen : %d,  recv package index : i = %d ", recvLen, i);          

			 if((ret = removed_sockfd_buf(clientFd)) < 0)
			 {
				myprint("Err : func removed_sockfd_buf()");
				break;
			 }
			 
        	 ret = read_data_proce(recvBuf, recvLen, ret);	        
        	 if(ret < 0)
        	 {
        	 	  myprint("Err : func read_data_proce() The index recv package i = %d !!! ", i);        	 	  
        	 	  break;
        	 }           	
        	 i++;
        }
       	else if(recvLen < 0)       	//The connect sockfd Error
       	{
       		if(errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
       		{
       			myprint("server: errno == EINTR || errno == EAGAIN ");         		
    			continue;  				
       		}
       		else 
       		{
       			myprint("ERror: server recv data ");         			
       			break;	
       		}       		
       	}
       	else if(recvLen == 0)		//client close
       	{
       		myprint("client closed ");               					
       		break;
       	}	      	
//		printf("\n\n");		
	} 

	close(clientFd);
	pthread_exit(NULL);
	return NULL;
}

void print_write_package(char *sendPackage)
{
	char *tmp = sendPackage + 1;
	myprint("func print_write_package()");
	printf_pack_news(tmp);

}

void push_info_toUi_array(int index, int fileFlag)
{
	if(fileFlag == 2)
	{
		push_info_toUi(index, 0);
		push_info_toUi(index, 1);
	}
	push_info_toUi(index, fileFlag);
}


void find_directory_file()
{
	char *direct = NULL;
	DIR *directory_pointer = NULL;
  	struct dirent *entry = NULL;
	struct stat  fileStat;
	static bool flag = false;
	int roundNum = 0, conIndex = 0, filyType = 0;
	char tableName[256] = { 0 }; 
	char templateName[256] = { 0 }; 
	char tmp01[256] = { 0 }, tmp02[256] = { 0 };
	
	struct FileModifyTime{
		char fileName[256];
		time_t modifyTime;
	};

	struct FileList{
		char fileName[256];
		struct FileList *next;
	}start, *node, *tmpNode;

	static struct FileModifyTime fileModifyTime[2];

	#if 0
	//1.��ȡĿ¼
	if((direct = getenv("SERverSourceDir")) == NULL)
	{
		myprint("Err : func getenv() key = SERverSourceDir");
		assert(0);
	}
	g_downLoadDir = direct;
	#endif

	//2. ��Ŀ¼, ��ȡĿ¼�е��ļ�
	if((directory_pointer = opendir(g_downLoadDir)) == NULL)
	{
		myprint("Err : func opendir() Dirpath : %s", direct);
		assert(0);
	}
	else
	{
		//3. ��ȡĿ¼�е��ļ�
		start.next = NULL;
		node = &start;
		while((entry = readdir(directory_pointer)))
		{
			node->next = (struct FileList*)malloc(sizeof(struct FileList));
			node = node->next;
			memset(node->fileName, 0, 256);
			sprintf(node->fileName, "%s%s", g_downLoadDir, entry->d_name);	
			node->next = NULL;
		}
		closedir(directory_pointer);
	}
	
	sprintf(tmp01, "%s.", g_downLoadDir);
	sprintf(tmp02, "%s..", g_downLoadDir);
	sprintf(tableName, "%s%s", g_downLoadDir, g_fileNameTable);
	sprintf(templateName, "%s%s", g_downLoadDir, g_fileNameTemplate);
	//4.������ȡ��Ŀ¼�µ��ļ�, ��ȡ���ǵ�ʱ������
	node = start.next;
	while(node)
	{	
		//4.1 ȥ��'.'��'..'Ŀ¼
		if(strcmp(node->fileName, tmp01) == 0 || strcmp(node->fileName, tmp02) == 0)
		{
			node = node->next;
			continue;
		}
			
		//4.2 ��ȡʣ���ļ�����
		memset(&fileStat, 0, sizeof(struct stat));
		if((stat(node->fileName, &fileStat)) < 0)
		{
			myprint("Err : func stat() filename : %s", node->fileName);
			assert(0);
		}

		//4.3 ���δ򿪸�Ŀ¼, �������ļ�������������
		if(!flag)
		{			
			fileModifyTime[roundNum].modifyTime = fileStat.st_atime;
			strcpy(fileModifyTime[roundNum].fileName, node->fileName);
		//	myprint("********** 6 ******************");
			conIndex = 0;
			while(conIndex < NUMBER)
			{
				if(g_thid_sockfd_block[conIndex].flag == 1)
				{
					if((strcmp(fileModifyTime[roundNum].fileName, templateName)) == 0)
						push_info_toUi(conIndex, 0);
					else if((strcmp(fileModifyTime[roundNum].fileName, tableName)) == 0)
						push_info_toUi(conIndex, 1);						
				}				
				conIndex++;
			}
		//	myprint("********** 8******************");	
					
		}
		else		//���״�, ���������ж�
		{				
			if((strlen(fileModifyTime[roundNum].fileName)) == 0 )
			{
				//myprint("********** 10 ******************");
				strcpy(fileModifyTime[roundNum].fileName, node->fileName);
				fileModifyTime[roundNum].modifyTime = fileStat.st_atime;
				if((strcmp(fileModifyTime[roundNum].fileName, templateName)) == 0)
				{
					filyType = 0;
				}	
				else if(strcmp(fileModifyTime[roundNum].fileName, tableName) == 0)
				{
					filyType = 1;		
				}
				else 
				{
					assert(0);
				}
				conIndex = 0;
				while(conIndex < NUMBER)
				{
					if(g_thid_sockfd_block[conIndex].flag == 1)		push_info_toUi(conIndex, filyType);
					conIndex++;
				}
				
			}
			else
			{		
				if((strcmp(fileModifyTime[roundNum].fileName, templateName)) == 0 && fileModifyTime[roundNum].modifyTime != fileStat.st_atime)				
				{
					filyType = 0;					
				}
				else if((strcmp(fileModifyTime[roundNum].fileName, tableName)) == 0 && fileModifyTime[roundNum].modifyTime != fileStat.st_atime)
				{
					filyType = 1;									
				}
				else
				{
					//myprint("fileModifyTime[%d].fileName : %s",roundNum, fileModifyTime[roundNum].fileName );
					goto End;
				}
				conIndex = 0;
				while(conIndex < NUMBER)
				{
					if(g_thid_sockfd_block[conIndex].flag == 1) 	push_info_toUi(conIndex, filyType);
					conIndex++;
				}	
			
				fileModifyTime[roundNum].modifyTime = fileStat.st_atime;
			}
					
		}			
	End:			
		roundNum++;
		node = node->next;
	
	}
	flag = true;
	
#if 1
	node = start.next;
	while(node)
	{
		tmpNode = node;
		node = node->next;
		free(tmpNode);			
	}
#endif	
	
}



void *child_write_func(void *arg)
{
	int ret = 0, j = 1;	
	char *sendDataAddr = NULL;
	int  sendDataLenth = 0;
	int  writeLenth = 0;
	int index = (int)arg;
	int clientFd = g_thid_sockfd_block[index].sockfd;
	int nWrite = 0;
	//bool flag = true;
//	int flag = 0;

	
	myprint("New thread will Send ...... ");
		
	while(1)
	{
		//sleep(10000);
		//push_info_toUi(index, 0);
		sem_wait(&(g_thid_sockfd_block[index].sem_send));		
		//1. get send Data And data Lenth
		if((ret = pop_queue_send_block(g_sendData_addrAndLenth_queue, &sendDataAddr, &sendDataLenth)) < 0)
		{
			myprint("Err : func pop_queue_send_block()");
			assert(0);
		}

		#if 0
		if(flag <= 4 * 1016 - 1 )
		{
			flag++;
			printf("j : %d\n", j++);
			continue;
		}
		#endif
	//	print_write_package(sendDataAddr);



		//2. send Data To client 	
		if(!g_thid_sockfd_block[index].encryptSendFlag)
	    	writeLenth = write(clientFd, sendDataAddr, sendDataLenth);
		else
		{
			myprint("\n\nSSL_write function... ");
			//writeLenth = SSL_write(g_thid_sockfd_block[index].sslHandle, sendDataAddr, sendDataLenth);   
		}		
        if(writeLenth < 0)
        {        	
        	myprint("ERror: server send data, sockfd : %d, sendData : %s, sendDataLenth : %d ", clientFd, sendDataAddr, sendDataLenth);     
       		goto End;
        }	
	    else if(writeLenth == sendDataLenth)
        {
	        nWrite += writeLenth;
//			myprint("********** have write Byte : %d **********", nWrite);
  //      	myprint("server write OK : %p, write data = [%d], encryptSendFlag : %d, j = %d ",
	//			sendDataAddr, writeLenth, g_thid_sockfd_block[index].encryptSendFlag, j++);              		        					

			//2.1 jurge send data style
			if(g_thid_sockfd_block[index].encryptChangeFlag)
			{
				g_thid_sockfd_block[index].encryptSendFlag = g_thid_sockfd_block[index].encryptRecvFlag;
				g_thid_sockfd_block[index].encryptChangeFlag = false;
				//2.1.1. send signal To thread recv
				myprint("will kill USR2 SIGNAL to read thread ID : %lu", g_thid_sockfd_block[index].pthidRead);
				if((ret = pthread_kill(g_thid_sockfd_block[index].pthidRead, SIGUSR2)) < 0)		assert(0);				
			}

			//2.2 free block to mempool
			if((ret = mem_pool_free(g_memoryPool, sendDataAddr)) < 0 )
			{
				myprint("Err : func mem_pool_free()");
				assert(0);
			}
        }
        else if(writeLenth == 0)
        {	        	
        	myprint("client closed!!! ");            	
       		goto End;
        }
		else
		{
			myprint("server write : %dj = [%d]	", writeLenth, j++);													
			assert(0);
		}
		
	//	printf("\n\n");
	}

End:	
	//if(g_thid_sockfd_block[index].encryptSendFlag)			SSL_shutdown(g_thid_sockfd_block[index].sslHandle);   
	//else
	close(clientFd);
#if 0
	SSL_free(g_thid_sockfd_block[index].sslHandle); 
	SSL_CTX_free(g_thid_sockfd_block[index].sslCtx);
#endif
	myprint("Thread send will close ...... ");
	pthread_exit(NULL);
	return NULL;
}


void *child_write_func02(void *arg)
{
	int ret = 0, j = 1;	
	char *sendDataAddr = NULL;
	int  sendDataLenth = 0;
	int  writeLenth = 0;
	int clientFd = (int)arg;
	
	myprint("client sockfd : %d", clientFd);
//	printf("\n\n");

	
	while(1)
	{
		myprint("----- sem_wait( g_sem_send ) begin");
		sem_wait( &g_sem_send);		
		
		if((ret = pop_queue_send_block(g_sendData_addrAndLenth_queue, &sendDataAddr, &sendDataLenth)) < 0)
		{
			myprint("Err : func pop_queue_send_block()");
			assert(0);
		}

	//	print_write_package(sendDataAddr);
		//send Data To client 
		#if 0
		do{
			
	        writeLenth = write(clientFd, sendDataAddr + nWrite, sendDataLenth - nWrite);
	        if(writeLenth < 0)
	        {        	
	        	myprint("ERror: server send data, sockfd : %d, sendData : %s, sendDataLenth : %d ", clientFd, sendDataAddr, sendDataLenth);     
	       		goto End;
	        }	     
	        else if(writeLenth == sendDataLenth)
	        {
	        	myprint("server write OK : %s, write data = [%d], j = [%d]  ", sendDataAddr, writeLenth, j++);              		        					
	        }
	        else if(writeLenth == 0)
	        {	        	
	        	myprint("client closed!!! ");            	
	       		goto End;
	        }
        
       		nWrite +=  writeLenth;
			

		}while(nWrite < sendDataLenth);
		
		if(nWrite == sendDataLenth)		
		{
			if((ret = mem_pool_free(g_memoryPool, sendDataAddr)) < 0 )
			{
				myprint("Err : func mem_pool_free()");
				assert(0);
			}
			else
			{
				myprint("func mem_pool_free() OK");
			}
		}
		else
		{
			myprint("Err : nWrite : %d != sendDataLenth : %d", nWrite, sendDataLenth);
			assert(0);
		}
		
		nWrite = 0;	
		sendDataAddr = NULL;
		sendDataLenth = 0;
		#endif
		
	    writeLenth = write(clientFd, sendDataAddr, sendDataLenth);
        if(writeLenth < 0)
        {        	
        	myprint("ERror: server send data, sockfd : %d, sendData : %s, sendDataLenth : %d ", clientFd, sendDataAddr, sendDataLenth);     
       		goto End;
        }	
	    else if(writeLenth == sendDataLenth)
        {
        	myprint("server write OK : %s, write data = [%d], j = [%d]  ", sendDataAddr, writeLenth, j++);              		        					
			if((ret = mem_pool_free(g_memoryPool, sendDataAddr)) < 0 )
			{
				myprint("Err : func mem_pool_free()");
				assert(0);
			}
        }
        else if(writeLenth == 0)
        {	        	
        	myprint("client closed!!! ");            	
       		goto End;
        }
//		printf("\n\n");
	}

End:	
	close(clientFd);
	#if 0
	if((ret = pthread_kill(g_threadContent[index].pthReadID, SIGKILL)) != 0)
	{
		myprint("Err : func pthread_kill()");
		assert(0);
	}
	#endif
	pthread_exit(NULL);
	return NULL;
}



//function: find  the whole packet; retval maybe error
int	find_whole_package(char *recvBuf, int recvLenth, int index)
{
	int ret = 0, i = 0;
	int  tmpContentLenth = 0;			//ת�������ݳ���
	char tmpContent[1400] = { 0 }; 		//ת��������
	static int flag = 0;				//flag ��ʶ�ҵ���ʶ��������;
	static int lenth = 0; 				//lenth : ��������ݰ����ݳ���
	static char content[2800] = { 0 };	//������������������, 		
	char *tmp = NULL;


	tmp = content + lenth;
	for(i = 0; i < recvLenth; i++)
	{
		//1. �������ݱ�ͷ
		if(recvBuf[i] == 0x7e && flag == 0)
		{
			flag = 1;
			continue;
		}
		else if(recvBuf[i] == 0x7e && flag == 1)	
		{		//2. �������ݱ�β, ��ȡ���������ݰ�

			//3.�����ݰ����з�ת�� 
			if((ret = anti_escape(content, lenth, tmpContent, &tmpContentLenth)) < 0)
			{
				myprint("Err : func anti_escape(), srcLenth : %d, dstLenth : %d",lenth,tmpContentLenth);
				goto End;
			}

			//4.��ת�������ݰ����д���
			if((ret = read_data_proce(tmpContent, tmpContentLenth, index)) < 0)
			{
				myprint("Err : func read_data_proce(), dataLenth : %d", tmpContentLenth);
				goto End;
			}
			else
			{
				//clear the variable
				memset(content, 0, sizeof(content));
				memset(tmpContent, 0, sizeof(tmpContent));								
				lenth = 0;
				flag = 0;	
				tmp = content + lenth;
			}
		}
		else
		{
			//5. training in rotation
			*tmp++ = recvBuf[i];
			lenth += 1;
			continue;
		}
	}


End:

	
	return ret;
}


//���տͻ��˵����ݰ�, recvBuf: ����: ��ʶ�� + ��ͷ + ���� + У���� + ��ʶ��;   recvLen : recvBuf���ݵĳ���
//				sendBuf : �������ݰ�, ��Ҫ���͵�����;  sendLen : �������ݵĳ���
int read_data_proce(char *recvBuf, int recvLen, int index)
{
	int ret = 0 ;	
	packHead *tmpHead = NULL;
	
		
	//2. jump The cmd And store The serial Number from recv package
	tmpHead = (packHead *)recvBuf;
	g_flag = tmpHead->seriaNumber;
	
	switch (tmpHead->cmd){
		case 0x01: 		//��¼���ݰ�
			if((ret = data_un_packge(login_func_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func login_func_reply() ");				
			break;
		case 0x02: 		//�˳����ݰ�
			if((ret = data_un_packge(exit_func_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func exit_func_reply() ");				
			break;
		case 0x03: 		//�������ݰ�
			if((ret = data_un_packge(heart_beat_func_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func heart_beat_func_reply() ");
			break;
		case 0x04: 		//ģ������			
			if((ret = data_un_packge(downLoad_template_func_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func downLoad_template_func_reply() ");
			break;
		case 0x05: 		//�ͻ�����Ϣ����
			if((ret = data_un_packge(get_FileNewestID_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func client_request_func_reply() ");
			break;
		case 0x06: 		//�ϴ�ͼƬ���ݰ�
			if((ret = data_un_packge(upload_func_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func upload_func_reply() ");
			break;
		case 0x07:
			if((ret = data_un_packge(push_info_toUi_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func upload_func_reply() ");
			break;
		case 0x09: 		//ɾ��ͼƬ���ݰ�
			if((ret = data_un_packge(delete_func_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func delete_func_reply() ");
			break;
		case 0x0C:		//�ϴ�ģ��
			if((ret = data_un_packge(template_extend_element_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func template_extend_element() ");
			break;
		case 0x0D:		//�ϴ�ͼƬ��
			if((ret = data_un_packge(upload_template_set_reply, recvBuf, recvLen, index)) < 0)
				myprint("Error: func upload_template_set ");
			break;
		case 0x0E:
			if((ret = data_un_packge(encryp_or_cancelEncrypt_transfer, recvBuf, recvLen, index)) < 0)
				myprint("Error: func encryp_or_cancelEncrypt_transfer_reply ");
			break;
		default:			
			printf_pack_news(recvBuf);
			assert(0);			
	}
	
	
	return ret;
}



//���տͻ��˵����ݰ�, recvBuf: ����: ��ʶ�� + ��ͷ + ���� + У���� + ��ʶ��;   recvLen : recvBuf���ݵĳ���
//				sendBuf : �������ݰ�, ��Ҫ���͵�����;  sendLen : �������ݵĳ���
int read_data_proce_0531(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0 ;	
	
	char buf[2800] = { 0 };	
	packHead *tmpHead = NULL;

	
	//1. buf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  outDataLenth : ����Ϊ buf ������ ����
	ret = anti_escape(recvBuf + 1,  recvLen - 2, buf, &outDataLenth);
	if(ret < 0)
	{
		myprint("Err : func anti_escape() !!!! ");    
		return ret;
	}
		
	//2. jump The cmd And store The serial Number from recv package
	tmpHead = (packHead *)buf;
	g_flag = tmpHead->seriaNumber;
	
	switch (tmpHead->cmd){
		case 0x01: 		//��¼���ݰ�
			if((ret = data_un_packge(login_func_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func login_func_reply() ");				
			break;
		case 0x02: 		//�˳����ݰ�
			if((ret = data_un_packge(exit_func_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func exit_func_reply() ");				
			break;
		case 0x03: 		//�������ݰ�
			if((ret = data_un_packge(heart_beat_func_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func heart_beat_func_reply() ");
			break;
		case 0x04: 		//ģ������			
			if((ret = data_un_packge(downLoad_template_func_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func downLoad_template_func_reply() ");
			break;
		case 0x05: 		//�ͻ�����Ϣ����
			if((ret = data_un_packge(get_FileNewestID_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func client_request_func_reply() ");
			break;
		case 0x06: 		//�ϴ�ͼƬ���ݰ�
			if((ret = data_un_packge(upload_func_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func upload_func_reply() ");
			break;
		case 0x07:
			if((ret = data_un_packge(push_info_toUi_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func upload_func_reply() ");
			break;
		case 0x09: 		//ɾ��ͼƬ���ݰ�
			if((ret = data_un_packge(delete_func_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func delete_func_reply() ");
			break;
		case 0x0C:		//�ϴ�ģ��
			if((ret = data_un_packge(template_extend_element_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func template_extend_element() ");
			break;
		case 0x0D:		//�ϴ�ͼƬ��
			if((ret = data_un_packge(upload_template_set_reply, buf, outDataLenth, index)) < 0)
				myprint("Error: func upload_template_set ");
			break;
		case 0x0E:
			if((ret = data_un_packge(encryp_or_cancelEncrypt_transfer, buf, outDataLenth, index)) < 0)
				myprint("Error: func encryp_or_cancelEncrypt_transfer_reply ");
			break;
		default:			
			printf_pack_news(buf);
			assert(0);			
	}
	
	
	return ret;
}

int data_un_packge(call_back_un_pack func_handle, char *recvBuf, int recvLen, int index)
{
	int ret = 0;
	
	if( (ret = func_handle(recvBuf, recvLen, index)) < 0)		
		myprint("Error:  func func_handle() ");
		
	return ret;
}

/*�����ݰ���ͷ��ֵ
*@param : head ��ֵ�ı�ͷ
*@param : cmd �����ݰ���������
*@param : contentLenth �����ݰ��ĳ���(��ͷ + ��Ϣ��)
*@param : subPackOrNo �ñ����Ƿ�Ϊ�ְ�����
*@param : machine ������

*@param : totalPackNum �ñ��ĵ��ܴ������
*@param : indexPackNum ��ǰ�������
*/
void assign_pack_head(void *srcHead, uint8_t cmd, int serial, uint32_t contentLenth, uint8_t subPackOrNo, char *machine,  uint16_t totalPackNum, uint16_t indexPackNum)   
{	
	memset(srcHead, 0, sizeof(packHead));
	packHead *head = (packHead *)srcHead;
	head->contentLenth = contentLenth;
	head->cmd = cmd;
	head->subPackOrNo = subPackOrNo;
	memcpy(head->machineCode, machine, 12);
	/*
	if(cmd != 0x87)		head->seriaNumber = g_flag;
	else				head->seriaNumber = serial;	
	*/
	head->seriaNumber = serial;
	head->packgeNews.totalPackge =  totalPackNum;
	head->packgeNews.indexPackge = indexPackNum;

}


//�����ϴ���ͼƬ�ϼ�
int save_set_picture_func(char *recvBuf, int recvLen)
{
	char *tmp = NULL;
	int lenth = 0, ret = 0;
	char TmpfileName[100] = { 0 };
	char fileName[100] = { 0 };
	char cmdBuf[1024] = { 0 };
	static FILE *fp = NULL;
	packHead *tmpHead = NULL;

	//0. ��ȡ���ݰ���Ϣ	
	tmpHead = (packHead *)recvBuf;

	if(tmpHead->packgeNews.indexPackge != 0 && tmpHead->packgeNews.indexPackge + 1 < tmpHead->packgeNews.totalPackge)
	{
		//1.�� ָ��ָ�� ͼƬ���ݵĲ���, ������д���ļ�
		tmp = recvBuf + sizeof(packHead) + 46 + 1;
		if((lenth = fwrite(tmp, 1, recvLen - sizeof(packHead) - sizeof(int) - 46 - 1, fp)) < 0)
		{
			myprint("Err : func fopen() : fileName : %s !!!", fileName);
			ret = -1;
			goto End;
		}
	}
	else if(tmpHead->packgeNews.indexPackge == 0)	
	{
		//2.��ȡ�ļ�����
		memcpy(TmpfileName, recvBuf + sizeof(packHead) + 1, 46);
		sprintf(fileName, "%s/%s", g_DirPath, TmpfileName );

		//3.�鿴�ļ��Ƿ����, ���ڼ�ɾ��
		if(if_file_exist(fileName))
		{			
			sprintf(cmdBuf, "rm %s", fileName);
			if(pox_system(cmdBuf) < 0)
			{
				myprint("Err : func pox_system()");
				ret = -1;
				goto End;
			}
		}

		//4.�����ļ�, ���ļ���д������
		if((fp = fopen(fileName, "ab")) == NULL)
		{
			myprint("Err : func fopen() : fileName : %s !!!", fileName);
			ret = -1;
			goto End;
		}		

		//5.�� ָ��ָ�� ͼƬ���ݵĲ���, ������д���ļ�
		tmp = recvBuf + sizeof(packHead) + 46 + 1 ; 
		if((lenth = fwrite(tmp, 1, recvLen - sizeof(packHead) - sizeof(int) - 46 - 1, fp)) < 0) 
		{
			myprint("Err : func fopen() : fileName : %s !!!", fileName);
			ret = -1;	
			goto End;
		}
	}
	else if(tmpHead->packgeNews.indexPackge + 1 == tmpHead->packgeNews.totalPackge)
	{
		//6.�� ָ��ָ�� ͼƬ���ݵĲ���, ������д���ļ�
		tmp = recvBuf + sizeof(packHead) + 46 + 1;
		if((lenth = fwrite(tmp, 1, recvLen - sizeof(packHead) - sizeof(int) - 46 - 1, fp)) < 0) 
		{		
			myprint("Err : func fopen() : fileName : %s !!!", fileName);		
			ret = -1;	
			goto End;
		}	
		fflush(fp); 
		fclose(fp);
		fp = NULL;
	}
	else
	{
		myprint("The package index is Err : %d !!! ",tmpHead->packgeNews.indexPackge );
		ret = -1;	
		goto End;
	}

End:
	if(ret < 0)	
	{	
		if(fp)			fclose(fp);		fp = NULL;
	}

	return 0;
}

//�������ݰ�	3�����ݰ�Ӧ��		
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int heart_beat_func_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0, checkNum = 0;
	char tmpSendBuf[1500] = { 0 };
	char *tmp = NULL, *sendBufStr = NULL;	
	char *machine = "123456789321";
	packHead head, *tmpHead = NULL;
	
	printf_pack_news(recvBuf);			//��ӡ�������ݰ���Ϣ

	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}

	
	//1.package The head news
	outDataLenth = sizeof(packHead);
	tmpHead = (packHead*)recvBuf;
	//assign_pack_head(&head, 0x83, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	assign_pack_head(&head, 0x83, tmpHead->seriaNumber, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	memcpy(tmpSendBuf, &head, sizeof(packHead));	
	
	//2.calculation checkCode
	tmp = tmpSendBuf + sizeof(packHead);
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//3. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;	
	
	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	//sem_post(&g_sem_send);

End:	
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
		
	return ret;
	
}


//����ģ�����ݰ�	4�����ݰ�Ӧ��		
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int downLoad_template_func_reply033(char *recvBuf, int recvLen)
{
	int ret = 0, outDataLenth = 0;
	packHead head;
	char *tmp = NULL, *sendBufStr = NULL;
	int contentLenth = 0;
	char *machine = "54454547871";
	int checkNum = 0, nRead = 0, readLenth = 0;
	char tmpSendBuf[1400] = { 0 };
	int  doucumentLenth = 1400 - sizeof(packHead) - 50 - 2 * sizeof(char) - sizeof(int);
	FILE *fp = NULL;
	char *fileName = "C_16_01_04_10_16_10_030_B_L.jpg";
	int totalPacka = 0;
	int indexNumber = 0;

	printf_pack_news(recvBuf);
	//1. open The template file
	if((fp = fopen(fileName, "rb+")) == NULL)
	{
		myprint("Err : func fopen()");
		goto End;
	}

	//2.get The file Total Package Number 
	if((ret = get_file_size(fileName, &totalPacka, doucumentLenth, NULL)) < 0)
	{
		myprint("Err : func get_file_size()");
		goto End;
	}

	//3.read The file content	
	while(!feof(fp))
	{
		if(indexNumber > totalPacka)		
		{
			myprint("indexNumber : %d, totalPacka : %d", indexNumber, totalPacka);
			assert(0);
		}
		tmp = tmpSendBuf + sizeof(packHead);
		memcpy(tmp, fileName, 50);
		tmp += 50;
		  		 
	    //3.1 get The part of The file conTent
	    #if 0
		if((nRead = fread(tmp , 1, doucumentLenth , fp)) < 0)
		{
			socket_log(SocketLevel[4], ret, "Error: func fread()");
			assert(0);
			goto End;
		}
#endif
		
		#if 1
		do{
	  	
		    readLenth = fread(tmp + nRead, 1, doucumentLenth - nRead, fp);
		    if(readLenth < 0)
		    {
			    socket_log(SocketLevel[4], ret, "Error: func fread()");
			    goto End;
		    }
		    nRead += readLenth;
		  
	     }while(nRead < doucumentLenth);
#endif
		 //3.2 The head  of The package
		 contentLenth = sizeof(packHead) + 50 + nRead;
		 //assign_pack_head(&head, 0x84, contentLenth, 1, machine, totalPacka, indexNumber);
		 assign_pack_head(&head, 0x84, 0, contentLenth, 1, machine, totalPacka, indexNumber);
//		 myprint("--- indexNumber : %d  begin", indexNumber);
		 indexNumber += 1;
//		 myprint("--- indexNumber : %d  end", indexNumber);
		 memcpy(tmpSendBuf, &head, sizeof(packHead));
		 
		 //3.3 calculate checkCode
		 checkNum = crc326(tmpSendBuf,  contentLenth);
		 memcpy(tmpSendBuf + contentLenth, &checkNum, sizeof(int));		 				  

		 //5.4 allock The block buffer in memory pool
		 sendBufStr = mem_pool_alloc(g_memoryPool);
		 if(!sendBufStr)
		 {			 
			 ret = -1;
			 socket_log(SocketLevel[4], ret, "Error: func mem_pool_alloc()");
			 goto End;
	 	 }
	
		 //5.6 escape the buffer
		 *sendBufStr = PACKSIGN;							 //flag 
		 ret = escape(PACKSIGN, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr+1, &outDataLenth);
		 if(ret != 0)
		 {
			 socket_log(SocketLevel[4], ret, "Error: func escape()");
			 goto End;
		 }
		 *(sendBufStr + outDataLenth + 1) = PACKSIGN; 	 //flag 

		 //5.7 push The sendData addr and sendLenth in queuebuf
		 ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + sizeof(char) * 2);
		 if(ret)
		 {
			 socket_log(SocketLevel[4], ret, "Error: func push_queue_send_block()");
			 goto End;
		 }
		 nRead = 0;
		 sem_post(&g_sem_send);
		 
	}
	

End:
	if(fp)		fclose(fp);
	
	return ret;
}


//����ģ�����ݰ�	4�����ݰ�Ӧ��		
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����  
//recvLen : ����Ϊ buf ������ ����
int downLoad_template_func_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0;
	packHead head, *tmpHead = NULL;
	char *tmp = NULL, *sendBufStr = NULL;
	int contentLenth = 0;
	char *machine = "54454547871";
	int checkNum = 0, nRead = 0;
	char tmpSendBuf[1400] = { 0 };
	int  doucumentLenth = 1400 - sizeof(packHead) - 3 * sizeof(char) - 2 * sizeof(char) - sizeof(int);
	FILE *fp = NULL;
	char fileName[1024] = { 0 };
	int totalPacka = 0;
	int indexNumber = 0;
	int fileType = 0;
	
	printf_pack_news(recvBuf);

	//1. get The downLoad file Type And downLoadFileID
	tmp = recvBuf + sizeof(packHead);
	if(*tmp == 0)			sprintf(fileName, "%s%s",g_downLoadDir, g_fileNameTemplate);
	else if(*tmp == 1)		sprintf(fileName, "%s%s",g_downLoadDir, g_fileNameTable);
	else					assert(0);
	fileType = *tmp;
	tmp++;
	myprint("downLoadFileName : %s", fileName);

	
	//2. open The template file
	if((fp = fopen(fileName, "rb+")) == NULL)
	{
		myprint("Err : func fopen()");
		goto End;
	}

	//2.get The file Total Package Number 
	if((ret = get_file_size(fileName, &totalPacka, doucumentLenth, NULL)) < 0)
	{
		myprint("Err : func get_file_size()");
		goto End;
	}
	
	tmpHead = (packHead *)recvBuf;

	//3.read The file content	
	while(!feof(fp))
	{
		 //3.1 get The part of The file conTent	And package The body News
		 memset(tmpSendBuf, 0, sizeof(tmpSendBuf));
		 tmp = tmpSendBuf + sizeof(packHead);
		 *tmp++ = 0;
		 *tmp++ = 2;
		 *tmp++ = fileType;		      
		 if((nRead = fread(tmp , 1, doucumentLenth , fp)) < 0)
		 {
			 myprint("Error: func fread()");
			 socket_log(SocketLevel[4], ret, "Error: func fread()");
			 assert(0);
			 goto End;
		 }
		 
		 //3.2 The head  of The package
		 contentLenth = sizeof(packHead) + nRead + 3 * sizeof(char);		 
		 assign_pack_head(&head, 0x84, tmpHead->seriaNumber, contentLenth, 1, machine, totalPacka, indexNumber);
		 indexNumber += 1;
		 memcpy(tmpSendBuf, &head, sizeof(packHead));
		
		 //3.3 calculate checkCode
		 checkNum = crc326(tmpSendBuf,  contentLenth);
		 memcpy(tmpSendBuf + contentLenth, &checkNum, sizeof(int));		 				  

		 //5.4 allock The block buffer in memory pool
		 sendBufStr = mem_pool_alloc(g_memoryPool);
		 if(!sendBufStr)
		 {			 
			 ret = -1;
			 socket_log(SocketLevel[4], ret, "Error: func mem_pool_alloc()");
			 goto End;
	 	 }
	
		 //5.6 escape the buffer
		 *sendBufStr = PACKSIGN;							 //flag 
		 ret = escape(PACKSIGN, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr+1, &outDataLenth);
		 if(ret != 0)
		 {
			 socket_log(SocketLevel[4], ret, "Error: func escape()");
			 goto End;
		 }
		 *(sendBufStr + outDataLenth + 1) = PACKSIGN; 	 //flag 

		 //5.7 push The sendData addr and sendLenth in queuebuf
		 ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + sizeof(char) * 2);
		 if(ret)
		 {
			 socket_log(SocketLevel[4], ret, "Error: func push_queue_send_block()");
			 goto End;
		 }
		
		 nRead = 0;		
		 sem_post(&(g_thid_sockfd_block[index].sem_send));
		 //sem_post(&g_sem_send);
		 
	}
	
	myprint("========5 === indexNumber : %d,    ret : %d =====", indexNumber, ret);


End:
	//print_write_package(sendBufStr);
	if(fp)		fclose(fp);
	return ret;
}


//�ϴ�ͼƬӦ�� ���ݰ�;  ��������һ�� �ظ�һ��.
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int downLoad_template_func_reply022(char *recvBuf, int recvLen)
{
	int ret = 0, outDataLenth = 0, checkNum = 48848748;
	char tmpSendBuf[1500] = { 0 };
	char *tmp = NULL, *sendBufStr = NULL;	
	char *machine = "123456789321";
	packHead head, *tmpHead = NULL;

	//printf_pack_news(recvBuf);					//��ӡ����ͼƬ����Ϣ

	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}

	
	#if 1
	//����ͼƬ
	ret = save_picture_func(recvBuf, recvLen);	
	if(ret)
	{
		printf("error: func save_picture_func() !!! [%d], [%s] \n", __LINE__, __FILE__);
		goto End;
	}
	#endif	
	
	//1.package The body News
	tmp = tmpSendBuf + sizeof(packHead);
	*tmp++ = 0x01;	
	outDataLenth = sizeof(packHead) + 1;
	
	//2.package The head news	
	tmpHead = (packHead*)recvBuf;
	//assign_pack_head(&head, 0x86, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	assign_pack_head(&head, 0x86, 0, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	memcpy(tmpSendBuf, &head, sizeof(packHead));	
		
	//3.���У����
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy(tmp, (char *)&checkNum, sizeof(checkNum));
		
	//4. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;
	
	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&g_sem_send);
		
End:
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
		
	return ret;
}




void print_client_request_reply(char *srcReplyNews)
{
	char *tmp = srcReplyNews;
	clientRequestContent *tmpReply = NULL;
	int i = 0, j = 0;

	if((tmpReply = malloc(sizeof(clientRequestContent))) == NULL)
		assert(0);

	tmpReply->projectNum = *tmp++;
	for (i = 0; i < tmpReply->projectNum; i++)
	{

		tmpReply->projectSet[i].projectID = *tmp++;
		tmpReply->projectSet[i].projectNameLenth = *tmp++;
		memcpy(tmpReply->projectSet[i].projectName, tmp, sizeof(tmpReply->projectSet[i].projectName));
		tmp += sizeof(tmpReply->projectSet[i].projectName);
		tmpReply->projectSet[i].optionNum = *tmp++;
		for (j = 0; j < tmpReply->projectSet[i].optionNum; j++)
		{
			tmpReply->projectSet[i].optionSet[j].optionID = *tmp++;
			tmpReply->projectSet[i].optionSet[j].optionNameLenth = *tmp++;
			memcpy(tmpReply->projectSet[i].optionSet[j].optionName, tmp, sizeof(tmpReply->projectSet[i].optionSet[j].optionName));
			tmp += sizeof(tmpReply->projectSet[i].optionSet[j].optionName);
		}
	}

	
	myprint("projectNum : %d",tmpReply->projectNum);
	for(i = 0; i < tmpReply->projectNum; i++)
	{
		myprint("project[%d]   proID : %d, proNameLenth : %d, proName : %s", i, 
			tmpReply->projectSet[i].projectID, 
			tmpReply->projectSet[i].projectNameLenth, 
			tmpReply->projectSet[i].projectName);
		myprint("project[%d]   optionNum : %d", i, tmpReply->projectSet[i].optionNum);
		for(j = 0; j < tmpReply->projectSet[i].optionNum; j++)		
			myprint("option[%d]  optID : %d, optNamelenth : %d, optName : %s", j, 
			tmpReply->projectSet[i].optionSet[j].optionID, 
			tmpReply->projectSet[i].optionSet[j].optionNameLenth, 
			tmpReply->projectSet[i].optionSet[j].optionName);		
	}
		
}

void packStruct(char *requestContent, int *outLenth)
{
	char *tmpOutSendBuf = requestContent;
	int i = 0, j = 0, lenth =0;
	int projectNum = 5, optionNum = 6;

	memset(requestContent, 0, sizeof(clientRequestContent));
	tmpOutSendBuf = requestContent;
#if 0
	*tmpOutSendBuf++ = projectNum;
	lenth += 1;
	for (i = 0; i < projectNum; i++)
	{
		*tmpOutSendBuf++ = 2;		//proID
		*tmpOutSendBuf++ = 6;		//proNameLenth
		memcpy(tmpOutSendBuf, "helloshu", 6);	//proName
		tmpOutSendBuf += 256;
		*tmpOutSendBuf++ = optionNum;		//optionNumber
		lenth += (3 + 256);
		for (j = 0; j < optionNum; j++)
		{
			*tmpOutSendBuf++ = 2;		//optionID
			*tmpOutSendBuf++ = 8;		//optionNamelenth
			memcpy(tmpOutSendBuf, "niao qwdq", 8);	//optionName
			tmpOutSendBuf += 256;
			lenth += (2 + 256);
		}
	
	}

	*outLenth = lenth;
#endif
#if 1
	//1. package struct	
	*tmpOutSendBuf++ = projectNum;					//projectNumber
	lenth += 1;
	for (i = 0; i < projectNum; i++)
	{
		*tmpOutSendBuf++ = 2;						//proID
		*tmpOutSendBuf++ = 6;						//proNameLenth
		memcpy(tmpOutSendBuf, "helloshu", 6);		//proName
		tmpOutSendBuf += sizeof(g_requestContent->projectSet->projectName);
		*tmpOutSendBuf++ = optionNum;				//optionNumber
		lenth += (3 + sizeof(g_requestContent->projectSet->projectName));
		for (j = 0; j < optionNum; j++)
		{
			*tmpOutSendBuf++ = 2;					//optionID
			*tmpOutSendBuf++ = 8;					//optionNamelenth
			memcpy(tmpOutSendBuf, "niao qwdq", 8);	//optionName
			tmpOutSendBuf += sizeof(g_requestContent->projectSet->optionSet->optionName);
			lenth += (2 + sizeof(g_requestContent->projectSet->optionSet->optionName));
			
		}
	
	}

	*outLenth = lenth;
#endif
	
}

//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��); 
//recvLen : ����Ϊ buf ������ ����
int get_FileNewestID_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0, checkNum = 0; 
	char *tmp = NULL, *sendBufStr = NULL;
	int fileType = 0;
	packHead  head, *tmpHead = NULL;
	char tmpSendBuf[1400] = { 0 };
	char *machine = "54454547871";	

	
	//1. get The file type
	tmp = recvBuf + sizeof(packHead);
	if(*tmp == 0)				fileType = 0;
	else if(*tmp == 1)			fileType = 1;
	else						assert(0);

	//2. alloc The memory block
	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}

	//3.package body news
	tmp = tmpSendBuf + sizeof(packHead);
	if(fileType == 0)			
	{
		*tmp++ = fileType;
		memcpy(tmp, &g_fileTemplateID, sizeof(long long int));		
	}
	else if(fileType == 1)
	{
		*tmp++ = fileType;
		memcpy(tmp, &g_fileTableID, sizeof(long long int));		
	}
	outDataLenth =  sizeof(packHead) + 65;
	tmp += 64;
	
	//4.package The head news	
	tmpHead = (packHead *)recvBuf;
	assign_pack_head(&head, 0x85, tmpHead->seriaNumber, outDataLenth, 1, machine, 1, 0);
	memcpy(tmpSendBuf, &head, sizeof(packHead));		
	
	//5.calculation checkCode
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//6. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//7. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;			
	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	
End:
	if(ret < 0)		if(sendBufStr)		mem_pool_free(g_memoryPool, sendBufStr);

	return ret;
}



//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��); 
//recvLen : ����Ϊ buf ������ ����
int checkOut_fileID_newest_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0, checkNum = 0;
	char *fileNameTemplate = "downLoadTemplateNewestFromServer_17_05_08.pdf";
	char *fileNameTable = "C_16_01_04_10_16_10_030_B_L.jpg";
	char *tmp = NULL, *sendBufStr = NULL;
	int fileType = 0;
	char fileName[65] = { 0 };
	int  comRet = 0;
	packHead  head;
	char tmpSendBuf[1400] = { 0 };
	char *machine = "54454547871";

	myprint("The queue have element number : %d ...", get_element_count_send_block(g_sendData_addrAndLenth_queue));


	
	//1. get The file type
	tmp = recvBuf + sizeof(packHead);
	if(*tmp == 0)				fileType = 0;
	else if(*tmp == 1)			fileType = 1;
	else						assert(0);
	tmp++;

	//2.get The fileID
	memcpy(fileName, tmp, 64);
//	printf("\n\n");
	myprint("checkFileName : %s", fileName);
	
	//3.compare The ID
	if(fileType == 0)		comRet = strcmp(fileName, fileNameTemplate);
	else if(fileType == 1)	comRet = strcmp(fileName, fileNameTable);


	//4. alloc The memory block
	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}
	
	//5.package body news
	tmp = tmpSendBuf + sizeof(packHead);
	if(comRet == 0)				*tmp++ = comRet;
	else						*tmp++ = 1;		
	outDataLenth =  sizeof(packHead) + 1;
	
	//6.package The head news	
	//assign_pack_head(&head, 0x85, outDataLenth, 1, machine, 1, 0);	
	assign_pack_head(&head, 0x85, 0, outDataLenth, 1, machine, 1, 0);
	memcpy(tmpSendBuf, &head, sizeof(packHead));		
	
	//3.calculation checkCode
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//4. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;	
		
	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	//sem_post(&g_sem_send);
	
End:
	if(ret < 0)		if(sendBufStr)		mem_pool_free(g_memoryPool, sendBufStr);

	return ret;
}


int client_request_func_reply(char *recvBuf, int recvLen, int srcIndex)
{
	int ret = 0, outDataLenth = 0, outDataLenthDest = 0;
	packHead head ;
	char  *sendBufStr = NULL;
	unsigned int contentLenth = 0;
	char *machine = "54454547871";
	int checkNum = 0;
	char tmpSendBuf[1500] = { 0 };
	int index = 0, totalNumber = 0;
	char *requestContent = NULL;
	int residualByte = 0;
	char *tmpOutSendBuf = NULL, *tmp = NULL;
	int  copywrite = 0, havewrite = 0;
	

	//1. package The whole body news
	if((requestContent = malloc(sizeof(clientRequestContent))) == NULL)
	{
		myprint("func malloc() clientRequestContent");
		assert(0);
	}

	//1. package struct News
	packStruct(requestContent, &outDataLenth);

	//2. calculate The totalNumber And Body content  Lenth	
	contentLenth = PACKMAXLENTH - sizeof(char) * 2 - sizeof(char) * 2 - sizeof(int) -sizeof(packHead);		//The content Lenth
	if((outDataLenth % contentLenth) > 0 )
		totalNumber = outDataLenth / contentLenth + 1;
	else
		totalNumber = outDataLenth / contentLenth;

	tmpOutSendBuf = (char*)requestContent;

	do
	{

		//1.package body news
		memset(tmpSendBuf, 0, sizeof(tmpSendBuf));		
		residualByte = outDataLenth - (index + 1) * contentLenth;
		if(residualByte > 0)	copywrite = contentLenth;
		else					copywrite = outDataLenth - index * contentLenth;
		tmp = tmpSendBuf + sizeof(packHead);
		*tmp++ = 0;
		*tmp++ = 2;
		memcpy(tmp, tmpOutSendBuf + havewrite, copywrite);
		havewrite += copywrite;

		//2.package head news
//		assign_pack_head(&head, 0x85, copywrite + sizeof(packHead) + sizeof(char)*2, 0, machine, totalNumber, index);
		assign_pack_head(&head, 0x85, 0, copywrite + sizeof(packHead) + sizeof(char)*2, 0, machine, totalNumber, index);

		memcpy(tmpSendBuf, &head, sizeof(packHead));
		index += 1;

		//3.checkNum
		checkNum = crc326(tmpSendBuf, head.contentLenth);
		memcpy(tmpSendBuf + head.contentLenth, &checkNum, sizeof(int));

		//4.alloc The send buffer memory
		if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
		{
			ret = -1;
			myprint("Err : func mem_pool_alloc()");
			goto End;
		}

		//5.escape
		ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenthDest);
		if(ret)
		{
			printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
			goto End;
		}

		//6.push The send Data Addr And lenth in queue
		*sendBufStr = 0x7e;
		*(sendBufStr + 1 + outDataLenthDest) = 0x7e;			
		if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenthDest + 2)) < 0)
		{
			myprint("Err : func push_queue_send_block()");
			assert(0);
		}	

		sem_post(&(g_thid_sockfd_block[srcIndex].sem_send));
		//sem_post(&g_sem_send);

	}while(index < totalNumber);

	//print_client_request_reply(tmpOutSendBuf);
End:
	if(requestContent)  free(requestContent);
	
	return ret;
}

void print_hex_buf(char *buf, int lenth)
{
	int i = 0;

	for(i = 0; i < lenth; i++)
	{
		printf("%x ", buf[i]);
	}
	printf("\n");
}

int client_request_func_reply022(char *recvBuf, int recvLen)
{
	int ret = 0, outDataLenth = 0;
	packHead head ;
	char  *sendBufStr = NULL;
	unsigned int contentLenth = 0;
	char *machine = "54454547871";
	int checkNum = 0;
	char tmpSendBuf[1500] = { 0 };
	int i = 0, j = 0, index = 0, totalNumber = 0;
	clientRequestContent *requestContent = NULL;
	
	int residualByte = 0;
	char *tmpOutSendBuf = NULL;
	int  copywrite = 0, havewrite = 0;
	

	printf_pack_news(recvBuf);
	//1. package The whole body news
	if((requestContent = malloc(sizeof(clientRequestContent))) == NULL)
	{
		myprint("func malloc() clientRequestContent");
		assert(0);
	}
	memset(requestContent, 0, sizeof(clientRequestContent));
	requestContent->projectNum = 10;
	for(i = 0; i < 10; i++)
	{		
		requestContent->projectSet[i].projectID = i+1;
		sprintf(requestContent->projectSet[i].projectName, "%d-project-%d", i+1, i+1);
		requestContent->projectSet[i].projectNameLenth = strlen(requestContent->projectSet[i].projectName);
		requestContent->projectSet[i].optionNum = 10;
		for(j = 0; j < 10; j++)
		{
			requestContent->projectSet[i].optionSet[j].optionID = j+1;
			sprintf(requestContent->projectSet[i].optionSet[j].optionName, "%d-option-%d", j+1, j+1);
			requestContent->projectSet[i].optionSet[j].optionNameLenth = strlen(requestContent->projectSet[i].optionSet[j].optionName);
		}
	}	

	
	outDataLenth = sizeof(clientRequestContent);		//total package Number of Bytes;
	contentLenth = PACKMAXLENTH - sizeof(char) * 2 - sizeof(int) -sizeof(packHead);		//The content Lenth
	if((outDataLenth % contentLenth) > 0 )
		totalNumber = outDataLenth / contentLenth + 1;
	else
		totalNumber = outDataLenth / contentLenth;

	tmpOutSendBuf = (char*)requestContent;

	do
	{
		//1.package body news
		memset(tmpSendBuf, 0, sizeof(tmpSendBuf));	
		residualByte = sizeof(clientRequestContent) - (index+1) * contentLenth;
		if(residualByte > 0)	copywrite = contentLenth;
		else					copywrite = sizeof(clientRequestContent) - index * contentLenth;
		memcpy(tmpSendBuf + sizeof(packHead), tmpOutSendBuf + havewrite, copywrite);
		havewrite += copywrite;

		//2.package head news
		//assign_pack_head(&head, 0x85, copywrite + sizeof(packHead), 0, machine, totalNumber, index);
		assign_pack_head(&head, 0x85, 0, copywrite + sizeof(packHead), 0, machine, totalNumber, index);
		memcpy(tmpSendBuf, &head, sizeof(packHead));
		index += 1;
		
		//3.checkNum
		checkNum = crc326(tmpSendBuf, head.contentLenth);
		memcpy(tmpSendBuf + head.contentLenth, &checkNum, sizeof(int));
		
		//4.alloc The send buffer memory
		if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
		{
			ret = -1;
			myprint("Err : func mem_pool_alloc()");
			goto End;
		}		
		
		//5.escape
		ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
		if(ret)
		{
			printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
			goto End;
		}

		//6.push The send Data Addr And lenth in queue
		*sendBufStr = 0x7e;
		*(sendBufStr + 1 + outDataLenth) = 0x7e;			
		if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
		{
			myprint("Err : func push_queue_send_block()");
			assert(0);
		}		
		sem_post(&g_sem_send);

	}while(index < totalNumber);
	myprint("------- end -------------");
	
	//print_client_request_reply(tmpOutSendBuf);
End:
	if(requestContent)  free(requestContent);
	
	return ret;
}




//ģ��ͼƬ���� ���ݰ�	13�����ݰ�Ӧ��		
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int upload_template_set_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0;
	packHead head, *tmpHead = NULL;
	char *tmp = NULL, *sendBufStr = NULL;
	unsigned int contentLenth = 0;
	char *machine = "54454547871";
	int checkNum = 0;
	char tmpSendBuf[1500] = { 0 };

	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}

	
	#if 1
	//����ͼƬ
	ret = save_set_picture_func(recvBuf, recvLen);	
	if(ret < 0 )
	{
		printf("error: func save_set_picture_func() !!! [%d], [%s] \n", __LINE__, __FILE__);
		goto End;
	}
	#endif	
	
	//0.��ӡͼƬ��Ϣ, ǿת����Ϊ�ṹ��,��ȡ���е���Ϣ
	//printf_pack_news(recvBuf);				//��ӡ����ͼƬ����Ϣ	
	tmpHead = (packHead*)recvBuf;
	
	//1.�����Ϣ��, �����ճɹ�����
	tmp = tmpSendBuf + sizeof(packHead); 
	*tmp++ = *(recvBuf + sizeof(packHead));
	
	#ifdef ERRORINPUT	
		if(*(recvBuf + sizeof(packHead)) == 3 && tmpHead->packgeNews.indexPackge == 100)			//����ļ���������ݻᷢ�ͳ���
		{
			//assert(0);
			*tmp++ = 1;
			*tmp++ = 1;		
			contentLenth = sizeof(packHead) + sizeof(unsigned char) * 3;	
		}
		else
		{
			*tmp++ = 0;
			contentLenth = sizeof(packHead) + sizeof(unsigned char) * 2;
		}
	#else
		*tmp++ = 0;
		contentLenth = sizeof(packHead) + sizeof(unsigned char) * 2;
	#endif
	
	//2.�����Ϣͷ
	assign_pack_head(&head, 0x8D, tmpHead->seriaNumber, contentLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	memcpy(tmpSendBuf, &head, sizeof(packHead));
	
	//3.���У����
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth );
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//4. ת����������
	ret = escape(0x7e, tmpSendBuf, contentLenth + 4, sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;	
	
	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
		assert(0);
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));

//	sem_post(&g_sem_send);
	
End:	
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
	
	return ret;	
}



//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����   
void printf_template_news(char *recvBuf)
{
	packHead *tmpHead = NULL;
	unsigned char IDLen = 0;
	char ID[128] = { 0 };
	unsigned char objectLen = 0;
	char object[400] = { 0 };
	unsigned char fileNum = 0;
	char fileName[10][50];
	unsigned char subMapCoordNum;			//������ͼ����
	Coords coorArray[50];
	char *tmp = NULL;
	int i = 0;
	UitoNetExFrame *tmpStruct = NULL;
//	int checkCode = 0;
	//Coords *tmpCoords = NULL;
	memset(fileName, 0, sizeof(fileName));
	memset(coorArray, 0,  sizeof(coorArray));
	
	tmpHead = (packHead*)recvBuf;
	printf("The package cmd : %d, indexNumber : %d, totalNumber : %d, contentLenth : %d, seriaNumber : %u, [%d], [%s] \n",tmpHead->cmd, tmpHead->packgeNews.indexPackge, 
			tmpHead->packgeNews.totalPackge, tmpHead->contentLenth + sizeof(int), tmpHead->seriaNumber, __LINE__, __FILE__);
	
	
	//1. ��ȡID
	tmp = recvBuf + sizeof(packHead);
	IDLen = *((unsigned char*)tmp);
	tmp += 1;
	memcpy(ID, tmp, IDLen);

	//2. ��ȡ�͹���
	tmp += IDLen;
	objectLen = *((unsigned char*)tmp);
	tmp += 1;
	memcpy(object, tmp, objectLen);

	//3. ��ȡ�Ծ�����
	tmp += objectLen;
	fileNum = *((unsigned char*)tmp);
	tmp += 1;
	for(i = 0; i < fileNum; i++)
	{
		memcpy(fileName[i], tmp, sizeof(tmpStruct->sendData.toalPaperName[0]));
		tmp += sizeof(tmpStruct->sendData.toalPaperName[0]);
	}

	//4. ��ȡ������
	subMapCoordNum = *((unsigned char*)tmp);
	tmp += 1;
	for(i = 0; i < subMapCoordNum; i++)
	{
		memcpy(&coorArray[i], tmp, sizeof(Coords));
		tmp += sizeof(Coords);
	}
	
	//6. ��ӡ
	myprint("IDLEN : %d, ID : %s", IDLen, ID);
	myprint("objectLen : %d, object : %s", objectLen, object);
	myprint("fileNum : %d", fileNum);
	for(i = 0; i < fileNum; i++)
	{
		myprint("paperIndex : %d, name : %s", i+1, fileName[i]);
	}
	myprint("subMapCoordNum : %d", subMapCoordNum);
	for(i = 0; i < subMapCoordNum; i++)
	{
		myprint("coorIndex : %d, coorMapID : %d, coors{%d, %d, %d, %d}", i+1, coorArray[i].MapID, 
				coorArray[i].TopX, coorArray[i].TopY, coorArray[i].DownX, coorArray[i].DownY);
	}
	
}



//ģ����չ���ݰ� ���ݰ�			12 �����ݰ�Ӧ��
/*@param : recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  
*@param :  recvLen : ����Ϊ buf ������ ����
*@param :  sendBuf : ���� client ����������
*@param :  sendLen : ���� �������ݵĳ���
*/
int template_extend_element_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0;
	packHead head, *tmpHead = NULL;
	char *tmp = NULL, *sendBufStr = NULL;
	unsigned int contentLenth = 0;
	char *machine = "54454547871";
	int checkNum = 47515;
	char tmpSendBuf[1500] = { 0 };

	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}
	
	printf_template_news(recvBuf);				//��ӡ����ͼƬ����Ϣ
	
	//1.�����Ϣͷ
	tmpHead = (packHead *)recvBuf;
	contentLenth = sizeof(packHead) + sizeof(unsigned char) * 1;
	assign_pack_head(&head, 0x8C, tmpHead->seriaNumber, contentLenth, 1, machine, 0, 0);
	
	//2.�����Ϣ��, �����ճɹ�����
	tmp = tmpSendBuf + sizeof(packHead); 
	memcpy(tmpSendBuf, &head, sizeof(packHead));
	*tmp++ = 0;
	
	//3.���У����
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth );
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//4. ת����������
	ret = escape(0x7e, tmpSendBuf, contentLenth + sizeof(uint32_t), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;	

	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	
End:	
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
		
	return ret;	
}



//ɾ��ͼƬӦ�� ���ݰ�			9 �����ݰ�
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int delete_func_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0, checkNum = 48848748;
	char tmpSendBuf[1500] = { 0 };
	char *tmp = NULL, *sendBufStr = NULL;	
	char *machine = "123456789321";
	char fileName[128] = { 0 };
	char rmFilePath[512] = { 0 };
	packHead head, *tmpHead = NULL;

	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}
	
	//1.printf The recvBuf news And delete The picture	
	printf_pack_news(recvBuf);			//��ӡ����ͼƬ����Ϣ
	memcpy(fileName, recvBuf + sizeof(packHead), recvLen - sizeof(packHead) - sizeof(int));
	sprintf(rmFilePath, "rm %s/%s", g_DirPath, fileName);	
	ret = system(rmFilePath);
	
	//2.package The body news	
	tmp = tmpSendBuf;	
	tmp += sizeof(packHead);		
	if(ret < 0 || ret == 127)
	{		
		*tmp++ = 0x01;	
		*tmp++ = 0;
		outDataLenth = sizeof(packHead) + 2;
	}
	else
	{
		*tmp++ = 0x00;	
		outDataLenth = sizeof(packHead) + 1;
	}
		
	//3.�����Ϣͷ
	tmpHead = (packHead*)recvBuf;
	assign_pack_head(&head, 0x89, tmpHead->seriaNumber, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	memcpy(tmpSendBuf, &head, sizeof(packHead));
	
	//4.���У����
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//5. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//6. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;	

	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	//sem_post(&g_sem_send);

End:	
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
		
	return ret;
}

//�˳���¼Ӧ�� ���ݰ�
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int exit_func_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0, checkNum = 48848748;
	char tmpSendBuf[1500] = { 0 };
	char *tmp = NULL, *sendBufStr = NULL;	
	char *machine = "123456789321";
	packHead head, *tmpHead = NULL;
		
	printf_pack_news(recvBuf);			//��ӡ����ͼƬ����Ϣ

	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}
	
	//1.package body news
	tmp = tmpSendBuf;			
	tmp += sizeof(packHead);
	*tmp++ = 0x01;	
	outDataLenth =  sizeof(packHead) + 1;
	
	//2.package The head news	
	tmpHead = (packHead*)recvBuf;
//	assign_pack_head(&head, 0x82, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	
	assign_pack_head(&head, 0x82, tmpHead->seriaNumber, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	memcpy(tmpSendBuf, &head, sizeof(packHead));		
	
	//3.calculation checkCode
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//4. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;	
		
	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	//sem_post(&g_sem_send);
	
End:	
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
		
	return ret;
}



//��¼Ӧ�����ݰ�
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int login_func_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0, checkNum = 48848748;
	char tmpSendBuf[1500] = { 0 };
	char *tmp = NULL, *sendBufStr = NULL;	
	char *machine = "123456789321";
	packHead head, *tmpHead = NULL;
		
	printf_pack_news(recvBuf);			//��ӡ����ͼƬ����Ϣ

	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}

	
	//1. package The body news
	tmp = tmpSendBuf;	
	tmp += sizeof(packHead);
	*tmp++ = 0x01;	
	outDataLenth = sizeof(packHead) + 1;
	
	//2.package The head news	
	tmpHead = (packHead*)recvBuf;	
	assign_pack_head(&head, 0x81, tmpHead->seriaNumber, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);

	memcpy(tmpSendBuf, &head, sizeof(packHead));				
	
	//3.���У����
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//4. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret < 0)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;	

	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	//sem_post(&g_sem_send);
End:	
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
		
	return ret;
	
}

//�ϴ�ͼƬӦ�� ���ݰ�;  ��������һ�� �ظ�һ��.
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int upload_func_reply(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0, checkNum = 48848748;
	char tmpSendBuf[1500] = { 0 };
	char *tmp = NULL, *sendBufStr = NULL;	
	char *machine = "123456789321";
	packHead head, *tmpHead = NULL;

	//printf_pack_news(recvBuf);					//��ӡ����ͼƬ����Ϣ

	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}

	
	#if 1
	//����ͼƬ
	ret = save_picture_func(recvBuf, recvLen);	
	if(ret)
	{
		printf("error: func save_picture_func() !!! [%d], [%s] \n", __LINE__, __FILE__);
		goto End;
	}
	#endif	
	
	//1.package The body News
	tmp = tmpSendBuf + sizeof(packHead);
	*tmp++ = 0x01;	
	outDataLenth = sizeof(packHead) + 1;
	
	//2.package The head news	
	tmpHead = (packHead*)recvBuf;
	//assign_pack_head(&head, 0x86, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);
	assign_pack_head(&head, 0x86, tmpHead->seriaNumber, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);

	memcpy(tmpSendBuf, &head, sizeof(packHead));	
		
	//3.���У����
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy(tmp, (char *)&checkNum, sizeof(checkNum));
		
	//4. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;
	
	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	//sem_post(&g_sem_send);
		
End:
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
		
	return ret;
}

int push_info_toUi_reply(char *recvBuf, int recvLen, int index)
{
	myprint("push infomation OK ... ");
	return 0;
}


//��������Ϣ����
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int push_info_toUi(int index, int fileType)
{
	int ret = 0, outDataLenth = 0, checkNum = 0;
	char *tmp = NULL, *sendBufStr = NULL;
	packHead  head;
	char tmpSendBuf[1400] = { 0 };
	char *machine = "54454547871";

	
	myprint("The queue have element number : %d ...", get_element_count_send_block(g_sendData_addrAndLenth_queue));

	//2.alloc The memory block
	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}
	
	//3.package body news
	tmp = tmpSendBuf + sizeof(packHead);
	if(fileType == 0)			
	{
		*tmp++ = fileType;
		memcpy(tmp, &g_fileTemplateID, sizeof(long long int));
		g_fileTemplateID++;
	}
	else if(fileType == 1)
	{
		*tmp++ = fileType;
		memcpy(tmp, &g_fileTableID, sizeof(long long int));
		g_fileTableID++;
	}
	outDataLenth = sizeof(packHead) + 65;
	tmp += 64;
		
	//4.package The head news	
	assign_pack_head(&head, 0x87, g_thid_sockfd_block[index].send_flag, outDataLenth, 1, machine, 1, 0);
	memcpy(tmpSendBuf, &head, sizeof(packHead));		
	g_thid_sockfd_block[index].send_flag++;
	
	//5.calculation checkCode
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy( tmp, (char *)&checkNum, sizeof(checkNum));
		
	//6. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//7. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;			
	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));
	
End:
	if(ret < 0) 	if(sendBufStr)		mem_pool_free(g_memoryPool, sendBufStr);

	return ret;


}


//����ͼƬ
//recvBuf : ת��֮�������:  ���� : ��Ϣͷ + ��Ϣ�� + У����     (ֻ��ȥ����, ������ʾ��);  recvLen : ����Ϊ buf ������ ����
int save_picture_func(char *recvBuf, int recvLen)
{
	char *tmp = NULL;
	int lenth = 0, ret = 0;
	char TmpfileName[100] = { 0 };
	char fileName[100] = { 0 };
	char cmdBuf[1024] = { 0 };
	static FILE *fp = NULL;
	packHead *tmpHead = NULL;



	//0. ��ȡ���ݰ���Ϣ
	tmpHead = (packHead *)recvBuf;
	
	if(tmpHead->packgeNews.indexPackge != 0 && tmpHead->packgeNews.indexPackge + 1 < tmpHead->packgeNews.totalPackge)
	{
		//1.�� ָ��ָ�� ͼƬ���ݵĲ���, ������д���ļ�
		tmp = recvBuf + sizeof(packHead) + 46 ;
		if((lenth = fwrite(tmp, 1, recvLen - sizeof(packHead) - sizeof(int) - 46, fp)) < 0)
		{
			myprint("Err : func fopen() : fileName : %s !!!", fileName);
			ret = -1;
			goto End;
		}
	
	}
	else if(tmpHead->packgeNews.indexPackge == 0)
	{
		//2.��ȡ�ļ�����
		memcpy(TmpfileName, recvBuf + sizeof(packHead), 46);
		sprintf(fileName, "%s/%s", g_DirPath, TmpfileName );

		//3.�鿴�ļ��Ƿ����, ���ڼ�ɾ��	
		if(if_file_exist(fileName))
		{
			sprintf(cmdBuf, "rm %s", fileName);
			if(pox_system(cmdBuf) < 0)
			{
				myprint("Err : func pox_system()");
				ret = -1;
				goto End;
			}
		}

		//4.�����ļ�, ���ļ���д������
		if((fp = fopen(fileName, "ab")) == NULL)
		{
			myprint("Err : func fopen() : fileName : %s !!!", fileName);
			ret = -1;
			goto End;
		}
		
		//5.�� ָ��ָ�� ͼƬ���ݵĲ���, ������д���ļ�
		tmp = recvBuf + sizeof(packHead) + 46 ;
		if((lenth = fwrite(tmp, 1, recvLen - sizeof(packHead) - sizeof(int) - 46, fp)) < 0)
		{
			myprint("Err : func fopen() : fileName : %s !!!", fileName);
			ret = -1;
			goto End;
		}
	}
	else if(tmpHead->packgeNews.indexPackge + 1 == tmpHead->packgeNews.totalPackge)
	{
		//6.�� ָ��ָ�� ͼƬ���ݵĲ���, ������д���ļ�
		tmp = recvBuf + sizeof(packHead) + 46 ;
		if((lenth = fwrite(tmp, 1, recvLen - sizeof(packHead) - sizeof(int) - 46, fp)) < 0)
		{
			myprint("Err : func fopen() : fileName : %s !!!", fileName);
			ret = -1;
			goto End;
		}
		fflush(fp);
		fclose(fp);
		fp = NULL;
	}
	else
	{
		myprint("The package index is Err : %d !!! ",tmpHead->packgeNews.indexPackge );
		ret = -1;
		goto End;
	}	


End:

	if(ret < 0)
	{
		if(fp)			fclose(fp);		fp = NULL;
	}
	
	return ret;
	
}

//��ӡ�������ݵ���Ϣ
void printf_pack_news(char *recvBuf)
{
	
	packHead *tmpHead = NULL;
	
	tmpHead = (packHead*)recvBuf;
	printf("The package cmd : %d, indexNumber : %d, totalNumber : %d, contentLenth : %d, seriaNumber : %u, [%d], [%s] \n",tmpHead->cmd, tmpHead->packgeNews.indexPackge, 
			tmpHead->packgeNews.totalPackge, tmpHead->contentLenth, tmpHead->seriaNumber, __LINE__, __FILE__);
	
}
#if 1
// packet cmd data process
int switch_cmd_data(char *actiBuf, int acatiLen, char **sendBuf, int *sendLen)
{
	int ret = 0;
	packHead *tmpHead = NULL;
	uint8_t cmd;
	
	tmpHead = (packHead *)actiBuf;
	cmd = (uint8_t)tmpHead->cmd;

	switch (cmd){
		case 0x01: 		//net����� �������ݰ�;  ��ʶ���ӶϿ�, �����������Ͽ����Ƿ������Ͽ�, ��ʱ�ϲ㵽��ȥ���� ������
			if((ret = data_un_packge(login_func_reply, actiBuf, acatiLen, ret)) < 0)
				printf("Error: login_func_reply()  \r\n");
			break;
		case 0x02: 		//net����� �������ݰ�;  ��ʶ���ӶϿ�, �����������Ͽ����Ƿ������Ͽ�, ��ʱ�ϲ㵽��ȥ���� ������
			if((ret = data_un_packge(exit_func_reply, actiBuf, acatiLen, ret)) < 0)
				printf( "Error: exit_func_reply()  \r\n");
			break;
		case 0x06: 		//net����� �������ݰ�;  ��ʶ���ӶϿ�, �����������Ͽ����Ƿ������Ͽ�, ��ʱ�ϲ㵽��ȥ���� ������
			if((ret = data_un_packge(upload_func_reply, actiBuf, acatiLen, ret)) < 0)
				printf( "Error: upload_func_reply() \r\n");
			break;
		case 0x09: 		//net����� �������ݰ�;  ��ʶ���ӶϿ�, �����������Ͽ����Ƿ������Ͽ�, ��ʱ�ϲ㵽��ȥ���� ������
			if((ret = data_un_packge(delete_func_reply, actiBuf, acatiLen, ret)) < 0)
				printf( "Error: delete_func_reply()  \r\n");
			break;
		default:
			{
				printf_pack_news(actiBuf);			
				assert(0);
			}
		}
	return ret;
}
#endif

/*read_package  ��һ������;
 *����: buf: �������������ڴ�, ������ȡ����һ������;
 *		maxline:  buf�ڴ�����ռ�
 *		sockfd:   ���ӵĽ���
 *		tmpFlag:  �� ��ȡ�� ���ݰ�����ȷʱ, �ٴ��ض�, ��Ҫ����ǰ��ı�ʶ��, ��֤���������ݰ�
 *����ֵ: ���ض�ȡ�����ݰ��к��е� �ֽ���;  == -1; ��ʾ����;  =0: ��ʾ�Զ˹ر�;  > 0: ��ʶ��ȷ,��һ�����ݰ����ֽ���
*/
int read_package(char *recvBuf, int dataLenth, char **sendBuf, int *sendLen)
{
	int ret = 0, i = 0;
	char buf[1400] = { 0 };	
	int  bufLen = 0;	
	char actiBuf[1400] = { 0 };
	int  acatiLen = 0;
	static int flag = 0;			// sign for the header and tailer identifier;  0: header; 1:tailer;
	char *tmpBuf = buf;
	packHead  *tmpHead = NULL;
	FILE *fp = NULL;	
	int fileLen = 0;			
	for(i = 0; i < dataLenth; i++)
	{
		if(i == dataLenth -1)		//print the last byte in buf;
		{
			printf("i == nread -1; recvBuf[i]: %d,  [%d], [%s]\n", recvBuf[i],  __LINE__, __FILE__);						
		}
		if(i == 0)				//print the first byte in buf;
		{
			printf("i == 0; recvBuf[i]: %d,  [%d], [%s]\n", recvBuf[i],  __LINE__, __FILE__);						
		}
				
		if(recvBuf[i] == 0x7e && flag == 0)	//find the header identifier 
		{					
			//�ҵ�һ����ʶ��ͷ��ʶ����
			++flag;
			continue;	
		}
		else if(recvBuf[i] == 0x7e && flag == 1)		//find the tail identifier
		{
			// find the whole package;
			
			// 1. anti_escape the recv data;
			ret = anti_escape(buf, bufLen, actiBuf, &acatiLen);
			if(ret)
			{
				printf("��ת�����!!!! [%d], [%s] \n", __LINE__, __FILE__);
				break;
			}
			tmpHead = (packHead*)actiBuf;		
			// 2. check the data lenth
			if(tmpHead->contentLenth + sizeof(uint32_t) == acatiLen)
			{
				// 3. data packet processing;	
				ret = switch_cmd_data(actiBuf, acatiLen, sendBuf, sendLen);
				if(ret)
				{
					printf("error: func switch_cmd_data(), [%d], [%s] \n", __LINE__, __FILE__);
					flag = 0;
					break;
				}
				else
				{
					flag = 0;		//����̬������ 0;
				}	
			}
			else
			{
				flag = 0;
				printf("error: mpHead->contentLenth + sizeof(int) != acatiLen!!!! [%d], [%s] \n", __LINE__, __FILE__);
				break;
			}			
		}
		else 
		{
			//copy the data packet
			*tmpBuf++ = recvBuf[i];
			bufLen += 1;
			continue;	
		}
	}

	if(recvBuf[i-1] != 0x7e)
	{
		fp = fopen("error_file.txt", "w");
		fileLen = fwrite(recvBuf, 1, dataLenth, fp);
		if(fileLen != dataLenth)
			assert(0);
		fclose(fp);
		printf("no find the whole packet : %d,  [%d], [%s]\n", recvBuf[i-1],  __LINE__, __FILE__);	
		flag = 0;					
		ret = 2;
	}	

	return ret;	
}


int std_err(const char* name)
{
    perror(name);
    exit(1);
}

void func_data(int sig)
{
	int pid = 0;
	while((pid = waitpid(-1, NULL, WNOHANG)) > 0)
	{
		;
	}
	
}

void func_pipe(int sig)
{
	int ret = 0;
	socket_log( SocketLevel[4], ret, "SIGPIPIE appear %d",  sig);	
}

int server_bind_listen_fd(char *ip, int port, int *listenFd)
{
	int ret = 0, sfd = 0,flag = 1;
	
	//�����������׽���
    sfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sfd == -1)
        std_err("socket");
    
    //�˿ڸ���            
   	ret = setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag));
	if(ret)
		std_err("setsockopt");			   
                
    //�����ַ����
    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    
	ret = inet_pton(AF_INET, ip, &serv_addr.sin_addr.s_addr);
  	if(ret != 1)
  		std_err("inet_pton");	
	
    //�󶨷�������IP���˿ڣ�
    ret = bind(sfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
    if(ret == -1)
        std_err("bind");


    //�������ӷ������Ŀͻ�����
    ret = listen(sfd, 99);
    if(ret == -1)
        std_err("listen");
	else
		printf("Server listen IP %s, Port : %d, [%d], [%s]\n\n", ip, port, __LINE__, __FILE__);
	*listenFd = sfd;
	
	return ret;
}

//��� �׽��ֻ�����������;
//˼��: ʹ��select����, ʵ��һ���������׽���, Ȼ���ظ��׽��ֵĶ���Ϊ,
//��ȡ������, ����������������;  ���׽�����������ʱ, ������ѭ��.
int removefd(int sockfd)
{
    int ret = 0;
    int nRet = 0;
    char buf[2] = { 0 };

    struct timeval tmOut;
    tmOut.tv_sec = 0;
    tmOut.tv_usec = 0;
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(sockfd, &fds);
    
    while(1)
    {
        nRet = select(sockfd + 1, &fds, NULL, NULL, &tmOut);

        if(nRet == 0)
            break;
        recv(sockfd, buf, 1, 0);
    }

    return ret;
}

/**
 * activate_noblock - ����I/OΪ������ģʽ
 * @fd: �ļ������
 */
int activate_nonblock(int fd)
{
	int ret = 0;
	int flags = fcntl(fd, F_GETFL);
	if (flags == -1)
	{
		ret = flags;
		Socket_Log(__FILE__, __LINE__,SocketLevel[4], ret,"func activate_nonblock() err");
		return ret;
	}
		
	flags |= O_NONBLOCK;
	ret = fcntl(fd, F_SETFL, flags);
	if (ret == -1)
	{
		Socket_Log(__FILE__, __LINE__,SocketLevel[4], ret,"func activate_nonblock() err");
		return ret;
	}
	return ret;
}
/**
 * deactivate_nonblock - ����I/OΪ����ģʽ
 * @fd: �ļ������
 */
int deactivate_nonblock(int fd)
{
	int ret = 0;
	int flags = fcntl(fd, F_GETFL);
	if (flags == -1)
	{
		ret = flags;
		Socket_Log(__FILE__, __LINE__,SocketLevel[4], ret,"func deactivate_nonblock() err");
		return ret;
	}

	flags &= ~O_NONBLOCK;
	ret = fcntl(fd, F_SETFL, flags);
	if (ret == -1)
	{
		Socket_Log(__FILE__, __LINE__,SocketLevel[4], ret,"func deactivate_nonblock() err");
		return ret;
	}
	return ret;
}

/**
 * recv_peek - �����鿴�׽��ֻ��������ݣ������Ƴ�����
 * @sockfd: �׽���
 * @buf: ���ջ�����
 * @len: ����
 * �ɹ�����>=0��ʧ�ܷ���-1
 */
ssize_t recv_peek(int sockfd, void *buf, size_t len)
{
	int ret = 0;
	
	while (1)
	{
		ret = recv(sockfd, buf, len, MSG_PEEK);
		if (ret == -1 && errno == EINTR)
			continue;
		
		return ret;
	}
}

//��� �׽��ֻ�����������;
int removed_sockfd_buf(int sockfd)
{
	int ret = 0, len = 0;
	char buf[1024] = { 0 };
	activate_nonblock(sockfd);
	do{
		len = recv_peek(sockfd, buf, sizeof(buf));
		if(len > 0)
		{
			 printf("\nrecv_peek() len : %d\n", len);
			 ret = recv(sockfd, buf, sizeof(buf), 0);
			 if(ret == -1 && errno == EINTR)		
			 	continue;
		}	
		
	}while(len > 0);
	

	deactivate_nonblock(sockfd);
	return ret;
}

#if 0
int ssl_server_init_handle(int socketfd, SSL_CTX **srcCtx, SSL **srcSsl)
{
	int ret = 0;
	const SSL_METHOD *meth = NULL;    
	SSL_CTX *ctx = NULL;    
	SSL *myssl = NULL;

	if(socketfd <= 0 || !srcCtx || !srcSsl)
	{
		ret = -1;
		socket_log( SocketLevel[4], ret, "Err : socketfd : %d, srcCtx : %p, srcSsl : %p", socketfd, srcCtx, srcSsl);
		goto End;
	}

	//1. init 
	SSL_library_init();    
	SSL_load_error_strings();	
	meth=SSLv23_server_method();
	myprint("===========  2  ============");

    /*2. Create a new context block*/
	ctx=SSL_CTX_new(meth);    
	if (!ctx) 
	{
		ret = -1;
		socket_log( SocketLevel[4], ret, "Err : func SSL_CTX_new() creating the context");
		goto End;
	}
	/*3. Set cipher list*/
	if (SSL_CTX_set_cipher_list(ctx, CIPHER_LIST) <= 0)
	{
		ret = -1;
		socket_log( SocketLevel[4], ret, "Err : func SSL_CTX_set_cipher_list() setting the cipher list");
		goto End;
	}
	/*4. Indicate the certificate file to be used*/
	if (SSL_CTX_use_certificate_file(ctx, CERT_FILE, SSL_FILETYPE_PEM) <= 0) 
	{
		ret = -1;
		socket_log( SocketLevel[4], ret, "Err : func SSL_CTX_use_certificate_file() setting the certificate file");
		goto End;
	}
				myprint("===========  3  ============");
	/*5. Indicate the key file to be used*/
	if (SSL_CTX_use_PrivateKey_file(ctx, KEY_FILE, SSL_FILETYPE_PEM) <= 0) 
	{
		ret = -1;
		socket_log( SocketLevel[4], ret, "Err : func SSL_CTX_use_PrivateKey_file() setting the key file");		
		goto End;
	}
	/*6. Make sure the key and certificate file match*/
	if (SSL_CTX_check_private_key(ctx) == 0) 
	{
		ret = -1;
		socket_log( SocketLevel[4], ret, "Err : func SSL_CTX_check_private_key() Private key does not match the certificate public key");		
		goto End;		
	}
				myprint("===========  4  ============");
	/*7. Used only if client authentication will be used*/
	SSL_CTX_set_verify(ctx,SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT,NULL);
	/*8. Set the list of trusted CAs based on the file and/or directory provided*/
	if(SSL_CTX_load_verify_locations(ctx,CA_FILE, NULL)<1)
	{   
		ret = -1;
		socket_log( SocketLevel[4], ret, "Err : func SSL_CTX_load_verify_locations() setting the CA certificate file");		
		goto End;
	}
	/*9. Create new ssl object*/
	myssl=SSL_new(ctx);
	if(!myssl) 
	{
		ret = -1;
		socket_log( SocketLevel[4], ret, "Err : func SSL_new()");		
		goto End;
	}
				myprint("===========  5  ============");

	/*10. Bind the socket to the SSL structure*/
	SSL_set_fd(myssl, socketfd);
	/*11. Connect to the server, SSL layer.*/
	ret = SSL_accept(myssl);
	if (ret != 1) 
	{
		myprint("===========  Err : func SSL_accept()  ============");
		ret=SSL_get_error(myssl,ret);
		socket_log( SocketLevel[4], ret, "Err : func SSL_get_error() SSL error #%d in accept,program terminated\n",ret);		
		ret = -1;
		goto End;		
	}
				myprint("===========  6  ============");
	printf("\n\nSSL connection on socket Version: %s, Cipher: %s ......\n", 		
				SSL_get_version(myssl),  SSL_get_cipher(myssl));
		
End:
	myprint("===========  ret : %d ============", ret);
	if(ret < 0)
	{		
		if(socketfd > 0)		close(socketfd);
		if(myssl)				SSL_free(myssl);
		if(ctx) 				SSL_CTX_free(ctx);	
	}
	else
	{	
		*srcCtx = ctx;
		*srcSsl = myssl;
	}
	
	return ret;	
}
#endif

int encryp_or_cancelEncrypt_transfer(char *recvBuf, int recvLen, int index)
{
	int ret = 0, outDataLenth = 0, checkNum = 48848748;
	char tmpSendBuf[1500] = { 0 };
	char *tmp = NULL, *sendBufStr = NULL;	
	char *machine = "123456789321";
	packHead head, *tmpHead = NULL;
		
	printf_pack_news(recvBuf);			//��ӡ����ͼƬ����Ϣ

	tmp = recvBuf + sizeof(packHead);

	if(*tmp == 0)		g_thid_sockfd_block[index].encryptRecvFlag = true;			//encrypt
	else if(*tmp == 1)	g_thid_sockfd_block[index].encryptRecvFlag = false;			//cancel encrypt
	else				assert(0);
	g_thid_sockfd_block[index].encryptChangeFlag = true;
	
	if((sendBufStr = mem_pool_alloc(g_memoryPool)) == NULL)
	{
		ret = -1;
		myprint("Err : func mem_pool_alloc()");
		goto End;
	}

	//1. package The body news
	*(tmpSendBuf + sizeof(packHead)) = 0;
	outDataLenth = sizeof(packHead) + 1;

	//2.package The head news	
	tmpHead = (packHead*)recvBuf;
	assign_pack_head(&head, 0x8E, tmpHead->seriaNumber, outDataLenth, 1, machine, tmpHead->packgeNews.totalPackge, tmpHead->packgeNews.indexPackge);

	memcpy(tmpSendBuf, &head, sizeof(packHead));

	//3.���У����
	checkNum = crc326((const char *)tmpSendBuf, head.contentLenth);
	memcpy( tmpSendBuf + head.contentLenth, (char *)&checkNum, sizeof(checkNum));

	//myprint("\n\n ****(((((((( checkCode : %d", checkNum);
	//4. ת����������
	ret = escape(0x7e, tmpSendBuf, head.contentLenth + sizeof(int), sendBufStr + 1, &outDataLenth);
	if(ret < 0)
	{
		printf("Error : func escape() escape() !!!!; [%d], [%s]\n", __LINE__, __FILE__);
		goto End;
	}
	
	//5. ��Ϸ��͵�����
	*sendBufStr = 0x7e;
	*(sendBufStr + 1 + outDataLenth) = 0x7e;	

	if((ret = push_queue_send_block(g_sendData_addrAndLenth_queue, sendBufStr, outDataLenth + 2)) < 0)
	{
		myprint("Err : func push_queue_send_block()");
	}

	sem_post(&(g_thid_sockfd_block[index].sem_send));

End:	
	if(ret < 0 && sendBufStr)   	mem_pool_free(g_memoryPool, sendBufStr);
		
	return ret;
}



